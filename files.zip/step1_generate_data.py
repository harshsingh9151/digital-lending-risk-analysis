# =============================================================================
# STEP 1 — SYNTHETIC DATASET GENERATION
# Digital Lending: Portfolio Optimization
# Consulting & Analytics Club, IIT Guwahati — Summer Projects '26
#
# WHAT THIS FILE DOES:
#   Generates a realistic fake dataset of 3000 loan customers.
#   Every column is designed to reflect how a real fintech company
#   would store customer and loan data.
#
# WHY SYNTHETIC AND NOT KAGGLE?
#   The problem statement requires you to design the data yourself.
#   This proves you understand what variables matter in lending —
#   not just that you can download a CSV.
#
# HOW TO RUN:
#   python3 step1_generate_data.py
#   Output: lending_portfolio.csv (3000 rows, 22 columns)
# =============================================================================

import numpy as np
import pandas as pd

# ── Reproducibility ──────────────────────────────────────────────────────────
# np.random.seed() ensures that every time you run this script,
# you get THE EXACT SAME dataset. Without this, numbers would be
# different every run and your analysis wouldn't be reproducible.
np.random.seed(42)

N = 3000  # number of customers


# =============================================================================
# SECTION 1 — CUSTOMER PROFILE
# These are the basic demographic and financial attributes of each customer.
# In a real fintech, this data comes from the loan application form +
# bureau checks (like CIBIL in India).
# =============================================================================

# Customer IDs — simple unique identifier for each customer
customer_id = [f"CUST{str(i).zfill(4)}" for i in range(1, N + 1)]
# zfill(4) pads with zeros → CUST0001, CUST0002 ... CUST3000
# Why? Looks professional, easy to sort, easy to reference

# Age — between 21 and 58
# Why this range? Below 21 = legal/risk issues. Above 58 = near retirement,
# banks get cautious. Most personal loan borrowers fall here.
age = np.random.randint(21, 58, N)

# Geography — Tier classification of city
# Why does this matter? Tier-1 cities (Mumbai, Delhi) → higher income,
# better repayment. Tier-3 → informal economy, higher default risk.
# We use weighted probabilities: more customers from Tier-1 than Tier-3.
geography = np.random.choice(
    ["Tier-1", "Tier-2", "Tier-3"],
    N,
    p=[0.40, 0.38, 0.22]   # 40% from Tier-1, 38% Tier-2, 22% Tier-3
)

# Employment Type — core risk driver
# Salaried = fixed monthly income → predictable repayment
# Self-employed = irregular income → higher risk
# Gig worker = very irregular → highest risk
employment_type = np.random.choice(
    ["Salaried", "Self-Employed", "Gig Worker"],
    N,
    p=[0.55, 0.30, 0.15]
)

# Monthly Income (in ₹) — income proxy
# We generate income BASED ON employment type and geography.
# This is called "conditional generation" — making realistic correlations.
# A Tier-1 salaried person earns more than a Tier-3 gig worker.
income = np.where(
    employment_type == "Salaried",
    np.random.randint(25000, 120000, N),    # Salaried: ₹25k–₹1.2L/month
    np.where(
        employment_type == "Self-Employed",
        np.random.randint(18000, 90000, N), # Self-Employed: ₹18k–₹90k
        np.random.randint(8000, 35000, N)   # Gig Worker: ₹8k–₹35k
    )
)
# np.where(condition, value_if_true, value_if_false) — like an IF statement

# Credit Score Band (proxy for CIBIL score)
# In reality: 300–900. We use bands for simplicity.
# Weaker employment + lower income → more likely to be in lower band.
# We build this correlation manually using employment type as a base.
credit_score_map = {
    "Salaried":      ["Prime", "Near-Prime", "Sub-Prime"],
    "Self-Employed": ["Prime", "Near-Prime", "Sub-Prime"],
    "Gig Worker":    ["Prime", "Near-Prime", "Sub-Prime"]
}
credit_probs = {
    "Salaried":      [0.55, 0.30, 0.15],  # Most salaried = Prime
    "Self-Employed": [0.35, 0.40, 0.25],  # Mixed
    "Gig Worker":    [0.15, 0.35, 0.50]   # Most gig = Sub-Prime
}
credit_score_band = np.array([
    np.random.choice(
        credit_score_map[emp],
        p=credit_probs[emp]
    )
    for emp in employment_type
])


# =============================================================================
# SECTION 2 — LOAN & PRODUCT DETAILS
# These columns describe the actual loan taken by the customer.
# In a real fintech: this is stored in the loan origination system (LOS).
# =============================================================================

# Product Type
product_type = np.random.choice(
    ["Personal Loan", "SME Working Capital", "BNPL"],
    N,
    p=[0.50, 0.25, 0.25]
)

# Loan Amount (in ₹) — ticket size varies by product
loan_amount = np.where(
    product_type == "Personal Loan",
    np.random.randint(50000, 500000, N),       # ₹50k–₹5L
    np.where(
        product_type == "SME Working Capital",
        np.random.randint(200000, 2000000, N), # ₹2L–₹20L
        np.random.randint(5000, 50000, N)      # BNPL: ₹5k–₹50k
    )
)

# Tenure in months — how long the loan runs
tenure_months = np.where(
    product_type == "Personal Loan",
    np.random.choice([12, 18, 24, 36, 48], N),
    np.where(
        product_type == "SME Working Capital",
        np.random.choice([6, 12, 18, 24], N),
        np.random.choice([1, 3, 6], N)          # BNPL is short-term
    )
)

# Interest Rate (%) — risk-based pricing
# Higher risk profile → higher rate charged
# This is how real lenders work: Sub-Prime pays more
rate_base = {
    "Prime":      np.random.uniform(10, 16, N),
    "Near-Prime": np.random.uniform(16, 22, N),
    "Sub-Prime":  np.random.uniform(22, 36, N)
}
interest_rate = np.array([
    rate_base[band][i]
    for i, band in enumerate(credit_score_band)
]).round(2)

# Origination Risk Grade — internal grade assigned at loan approval
# Think of it like A/B/C/D rating for the loan
# Strongly correlated with credit score band
grade_map = {
    "Prime":      ["A", "B"],
    "Near-Prime": ["B", "C"],
    "Sub-Prime":  ["C", "D"]
}
origination_grade = np.array([
    np.random.choice(grade_map[band])
    for band in credit_score_band
])

# Origination Date — when the loan was disbursed
# Spread across 3 years (2022–2024) to create cohort effects
origination_date = pd.to_datetime(
    np.random.choice(
        pd.date_range("2022-01-01", "2024-12-31"),
        N
    )
)


# =============================================================================
# SECTION 3 — ACQUISITION CHANNEL
# How did the customer come to know about and apply for this loan?
# This is critical: channel quality affects portfolio quality.
# =============================================================================

acquisition_channel = np.random.choice(
    ["Organic / Direct", "DSA / Agent", "Digital Ads", "Bank Referral", "Fintech Partner"],
    N,
    p=[0.20, 0.25, 0.25, 0.15, 0.15]
)

# Cost of Acquisition (CAC) in ₹ — how much it cost to acquire this customer
# Digital Ads and DSA/Agent are expensive channels
cac_map = {
    "Organic / Direct": (200, 800),
    "DSA / Agent":      (1500, 4000),
    "Digital Ads":      (1000, 3000),
    "Bank Referral":    (300, 1000),
    "Fintech Partner":  (800, 2500)
}
cac = np.array([
    np.random.randint(*cac_map[ch])
    for ch in acquisition_channel
])

# Approval Turnaround Time (TAT) in hours
# Organic applicants often have cleaner profiles → faster processing
tat_map = {
    "Organic / Direct": (2, 12),
    "DSA / Agent":      (12, 48),
    "Digital Ads":      (4, 24),
    "Bank Referral":    (6, 24),
    "Fintech Partner":  (1, 6)
}
approval_tat_hours = np.array([
    np.random.randint(*tat_map[ch])
    for ch in acquisition_channel
])


# =============================================================================
# SECTION 4 — BEHAVIORAL SIGNALS
# These signals come from the customer's transaction/banking behavior.
# In real fintechs: fetched via Account Aggregator or bank statement analysis.
# This is what makes digital lenders special — they use alternative data.
# =============================================================================

# Balance Volatility — how much does the customer's account balance fluctuate?
# High volatility = irregular income = higher default risk
# Scale: 0 (very stable) to 1 (extremely volatile)
balance_volatility = np.where(
    employment_type == "Salaried",
    np.random.uniform(0.05, 0.35, N),    # Salaried = stable
    np.where(
        employment_type == "Self-Employed",
        np.random.uniform(0.20, 0.65, N),
        np.random.uniform(0.40, 0.95, N) # Gig = very volatile
    )
).round(3)

# Cash Flow Consistency Score — does money come in regularly every month?
# 1 = perfectly consistent, 0 = very irregular
cashflow_consistency = (1 - balance_volatility + np.random.uniform(-0.1, 0.1, N)).clip(0, 1).round(3)

# Spending Shock — did the customer have a sudden large expense?
# 1 = yes (e.g. medical emergency, job loss), 0 = no
# Higher chance for gig workers and sub-prime customers
spending_shock_prob = np.where(
    credit_score_band == "Sub-Prime", 0.35,
    np.where(credit_score_band == "Near-Prime", 0.20, 0.10)
)
spending_shock = np.random.binomial(1, spending_shock_prob, N)
# np.random.binomial(1, p) = flip a coin with probability p of getting 1


# =============================================================================
# SECTION 5 — REPAYMENT BEHAVIOR + OUTCOMES
# This is the most important section — did the customer repay or default?
# We build DEFAULT PROBABILITY as a function of all risk factors above.
# This is what makes the data realistic and analyzable.
# =============================================================================

# Build default probability for each customer
# We start with a base rate and adjust based on risk factors
# Think of this as a simple scorecard

default_prob = (
    # Base default rate
    0.01

    # Credit score impact
    + np.where(credit_score_band == "Sub-Prime",  0.12, 0)
    + np.where(credit_score_band == "Near-Prime", 0.04, 0)

    # Employment impact
    + np.where(employment_type == "Gig Worker",    0.08, 0)
    + np.where(employment_type == "Self-Employed", 0.03, 0)

    # Geography impact
    + np.where(geography == "Tier-3", 0.05, 0)
    + np.where(geography == "Tier-2", 0.04, 0)

    # Behavioral signals impact
    + balance_volatility * 0.06
    + spending_shock * 0.05

    # Product impact
    + np.where(product_type == "BNPL", 0.05, 0)

    # Channel impact — Digital Ads customers tend to be riskier
    + np.where(acquisition_channel == "Digital Ads", 0.04, 0)
    + np.where(acquisition_channel == "DSA / Agent", 0.04, 0)
    + np.where(acquisition_channel == "Bank Referral", -0.05, 0)  # safer
).clip(0.01, 0.90)  # keep within realistic bounds

# Actual default outcome — 1 = defaulted, 0 = did not default
default_flag = np.random.binomial(1, default_prob, N)

# Loan Status — more granular than just default/no default
loan_status = np.empty(N, dtype=object)
for i in range(N):
    if default_flag[i] == 1:
        loan_status[i] = np.random.choice(["NPA", "Written Off"], p=[0.65, 0.35])
    else:
        loan_status[i] = np.random.choice(["Active", "Closed"], p=[0.55, 0.45])
# NPA = Non-Performing Asset (overdue but not yet written off)
# Written Off = bank has given up recovering
# Active = currently being repaid
# Closed = fully repaid

# Days Past Due (DPD) — how many days late on latest payment
# 0 = on time, 1-29 = early warning, 30+ = serious delinquency
dpd = np.where(
    default_flag == 1,
    np.random.randint(30, 365, N),    # defaulters have high DPD
    np.where(
        np.random.binomial(1, 0.15, N) == 1,
        np.random.randint(1, 29, N),  # 15% of non-defaulters: minor delays
        0                             # 85% of non-defaulters: on time
    )
)

# Repayment Ratio — what fraction of EMIs have been paid so far?
# 1.0 = perfect, 0.0 = none paid
repayment_ratio = np.where(
    default_flag == 1,
    np.random.uniform(0.0, 0.6, N),   # defaulters paid less
    np.random.uniform(0.7, 1.0, N)    # good customers paid most/all
).round(3)

# Number of previous loans with this lender (customer tenure)
previous_loans = np.random.choice([0, 1, 2, 3, 4], N, p=[0.40, 0.30, 0.15, 0.10, 0.05])


# =============================================================================
# SECTION 6 — ASSEMBLE THE DATAFRAME
# Now we combine all arrays into a single pandas DataFrame (like an Excel table)
# =============================================================================

df = pd.DataFrame({
    # Customer Profile
    "customer_id":          customer_id,
    "age":                  age,
    "geography":            geography,
    "employment_type":      employment_type,
    "monthly_income":       income,
    "credit_score_band":    credit_score_band,

    # Loan & Product
    "product_type":         product_type,
    "loan_amount":          loan_amount,
    "tenure_months":        tenure_months,
    "interest_rate_pct":    interest_rate,
    "origination_grade":    origination_grade,
    "origination_date":     origination_date,

    # Acquisition
    "acquisition_channel":  acquisition_channel,
    "cac_inr":              cac,
    "approval_tat_hours":   approval_tat_hours,

    # Behavioral Signals
    "balance_volatility":   balance_volatility,
    "cashflow_consistency": cashflow_consistency,
    "spending_shock":       spending_shock,
    "previous_loans":       previous_loans,

    # Repayment & Outcomes
    "dpd":                  dpd,
    "repayment_ratio":      repayment_ratio,
    "loan_status":          loan_status,
    "default_flag":         default_flag,
})

# Save to CSV
df.to_csv("/home/claude/lending_portfolio.csv", index=False)
# index=False → don't write row numbers into the file

print("=" * 60)
print("DATASET GENERATED SUCCESSFULLY")
print("=" * 60)
print(f"\nTotal customers     : {len(df):,}")
print(f"Total columns       : {len(df.columns)}")
print(f"\nDefault rate        : {df['default_flag'].mean():.1%}")
print(f"NPA / Written Off   : {(df['loan_status'].isin(['NPA','Written Off'])).sum():,}")
print(f"\nProduct mix:")
print(df['product_type'].value_counts().to_string())
print(f"\nChannel mix:")
print(df['acquisition_channel'].value_counts().to_string())
print(f"\nCredit band mix:")
print(df['credit_score_band'].value_counts().to_string())
print("\nFile saved: lending_portfolio.csv")
